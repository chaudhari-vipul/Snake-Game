package Game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePanal extends JPanel implements ActionListener,KeyListener
{
	private int [] snackxlength=new int[750];
	private int [] snackylength=new int[750];
	private int lengthOfSnack=3;
	private int[]xPos= {25,50,75,100,125,150,175,200,225,250,275,300,325,350,375,400,425,450,475,500,525,550,575,600,625,650,675,700,725,750,775,800,825,850};
	private int[]yPos= {75,100,125,150,175,200,225,250,275,300,325,350,375,400,425,450,475,500,525,550,575,600,625};
	
	private Random random=new Random();
	private int enemyx,enemyy;
	
	private boolean left=false;
	private boolean right=true;
	private boolean up=false;
	private boolean down=false;
	private int moves=0;
	private int score=0;
	private boolean gameOver=false;
	
	private ImageIcon snaktitle=new ImageIcon(getClass().getResource("snaketitle.jpg"));
	private ImageIcon leftmouth=new ImageIcon(getClass().getResource("leftmouth.png"));
	private ImageIcon rightmouth=new ImageIcon(getClass().getResource("rightmouth.png"));
	private ImageIcon upmouth=new ImageIcon(getClass().getResource("upmouth.png"));
	private ImageIcon downmouth=new ImageIcon(getClass().getResource("downmouth.png"));
	private ImageIcon snakeimage=new ImageIcon(getClass().getResource("snakeimage.png"));
	private ImageIcon enemy=new ImageIcon(getClass().getResource("enemy.png"));
	private Timer timer;
	private int delay=100;
	
	
	
	public GamePanal() 
	{
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(true);
		timer=new Timer(delay, this);
		timer.start();
		
		newEnemy();
	}
	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(Color.WHITE);
		g.drawRect(24,10,851,55);
		g.drawRect(24,74,851,576);
		snaktitle.paintIcon(this, g, 25,11);
		g.setColor(Color.BLACK);
		g.fillRect(25,75,850,575);
		if(moves==0) {
			snackxlength[0]=100;
			snackxlength[1]=75;
			snackxlength[2]=50;
			snackylength[0]=100;
			snackylength[1]=100;
			snackylength[2]=100;
			
		}
		if(left) {
			leftmouth.paintIcon(this, g, snackxlength[0],snackylength[0]);	
		}
		if(right) {
			rightmouth.paintIcon(this, g, snackxlength[0],snackylength[0]);	
		}
		if(up) {
			upmouth.paintIcon(this, g, snackxlength[0],snackylength[0]);	
		}
		if(down) {
			downmouth.paintIcon(this, g, snackxlength[0],snackylength[0]);	
		}
		
		for (int i = 1; i < lengthOfSnack; i++) {
			snakeimage.paintIcon(this, g, snackxlength[i],snackylength[i]);	
		}
		enemy.paintIcon(this, g, enemyx, enemyy);
		if(gameOver) {
			g.setColor(Color.WHITE);
			g.setFont(new Font("Arial",Font.BOLD,50));
			g.drawString("Game Over ....", 300,300);
			g.setFont(new Font("Arial",Font.PLAIN,20));
			g.drawString("Press Enter to Restart....", 320,350);
		}
		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial",Font.PLAIN,14));
		g.drawString("Score :"+score, 750,30);
		g.drawString("Length :"+lengthOfSnack, 750,50);
		g.dispose();
			
	}
	public void actionPerformed(ActionEvent e) {
		for (int i = lengthOfSnack-1; i>0; i--) {
			snackxlength[i]=snackxlength[i-1];
			snackylength[i]=snackylength[i-1];
			
		}
		
		
		if(left) {
			snackxlength[0]=snackxlength[0]-25;
		}
		if(right) {
			snackxlength[0]=snackxlength[0]+25;
		}
		if(up) {
			snackylength[0]=snackylength[0]-25;
		}
		if(down) {
			snackylength[0]=snackylength[0]+25;
		}
		if(snackxlength[0]>850) snackxlength[0]=25;
		if(snackxlength[0]<25) snackxlength[0]=850;
		
		if(snackylength[0]>625) snackylength[0]=75;
		if(snackylength[0]<75) snackylength[0]=625;
		collideswithBody();
		collideswithEnemy();
		repaint();
	}
	public void keyPressed(KeyEvent e) 
	{
		if(e.getKeyCode()==KeyEvent.VK_SPACE) {
			restart();
		}
		
		
		
	if(e.getKeyCode()==KeyEvent.VK_LEFT && (!right)) {
		left=true;
		right=false;
		up=false;
		down=false;
		moves++;
	}
	if(e.getKeyCode()==KeyEvent.VK_RIGHT && (!left)) {
		left=false;
		right=true;
		up=false;
		down=false;
		moves++;
	}
	if(e.getKeyCode()==KeyEvent.VK_UP && (!down)) {
		left=false;
		right=false;
		up=true;
		down=false;
		moves++;
	}
	if(e.getKeyCode()==KeyEvent.VK_DOWN && (!up)) {
		left=false;
		right=false;
		up=false;
		down=true;
		moves++;
	}	
	}
	private void newEnemy() {
	enemyx=xPos[random.nextInt(34)];
	enemyy=yPos[random.nextInt(23)];
	for (int i = lengthOfSnack-1; i > 0; i--) {
		if (snackxlength[i]==enemyx && snackylength[i]==enemyy) {
			newEnemy();
		}
	}
	}
	private void collideswithEnemy() {
		if(snackxlength[0]==enemyx && snackylength[0]==enemyy ) {
			newEnemy();
			lengthOfSnack++;
			score++;
		}
	}
	private void collideswithBody() {
		for (int i = lengthOfSnack-1; i >0; i--) {
			if(snackxlength[i]==snackxlength[0] && snackylength[i]==snackylength[0]) {
				timer.stop();
				gameOver=true;
			}
		}
	}
	private void restart() {
		gameOver=false;
		moves=0;
		score=0;
		lengthOfSnack=0;
		left=false;
		right=false;
		up=false;
		down=false;
		timer.start();
		repaint();
	}
	public void keyTyped(KeyEvent e) {	
	}
	public void keyReleased(KeyEvent e) {
		
	}
	
}
