package Game;

import java.awt.Color;

import javax.swing.*;

public class MainClass {

	public static void main(String[]args) {
		JFrame frame=new JFrame("Snake Game");
		frame.setBounds(200,10,905,700);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GamePanal panel=new GamePanal();
		panel.setBackground(Color.DARK_GRAY);
		frame.add(panel);
		
		frame.setVisible(true);
	}
}
