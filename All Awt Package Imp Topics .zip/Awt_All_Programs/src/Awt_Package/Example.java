package Awt_Package;

import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class Example extends Frame
{
	public Example()
		{
		setVisible(true);	
		setSize(400,400);
		setLocation(300,300);
		
		}
	public static void main(String[] args) 
	{	
		Example l1=new Example();
		l1.addWindowListener(new WindowListener() {
			public void windowOpened(WindowEvent e)
			{
			System.out.println("Window Is Opened");	
			}
			public void windowClosing(WindowEvent e) 
			{
			System.out.println("Window is closing");
			getWindows();
			l1.dispose();
			}
			public void windowClosed(WindowEvent e)
			{
				System.out.println("Window is closed");		
			}
			public void windowIconified(WindowEvent e) 
			{
				System.out.println("Window is Iconified");
				
			}
			public void windowDeiconified(WindowEvent e) 
			{
				System.out.println("Window is Deiconified");
			}
			public void windowActivated(WindowEvent e) 
			{
				System.out.println("Window is Activated");	
			}

			public void windowDeactivated(WindowEvent e) 
			{
				System.out.println("Window is Deactivated");			
			}	
		});
	}
}

