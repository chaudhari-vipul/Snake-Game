package Awt_Package;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Assignment_3 extends Frame
{
	private Label Email,Pass;
	private TextField EmailText,PassText;
	private Button Login;
	

	Assignment_3()
	{
		setTitle("Assignment 3");
		setVisible(true);
		setSize(200,300);
		setLayout(new GridLayout(3,2));
		init();
		AddingComponents();
		pack();
		
	}
	public void AddingComponents() 
	{
		add(Email);
		add(EmailText);
		add(Pass);
		add(PassText);
		add(Login);
		
	}
	public void init() {
		Email=new Label("Enter the email    :");
		Pass=new Label("Enter the password  :");
		EmailText=new TextField(20);
		PassText=new TextField(20);
		Login=new Button("<-----Login---->");
		
		Login.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Dialog d=new Dialog(Assignment_3.this);
				d.setVisible(true);
				Label success=new Label("Login Success");
				Label Email=new Label("Email is :"+EmailText.getText());
				Label Pass=new Label("Password is :"+PassText.getText());
				d.setLayout(new GridLayout(3,1));
				d.add(Email);
				d.add(Pass);
				d.add(success);
				d.pack();
			}
		});
	}
	public static void main(String[] args) 
	{
		Assignment_3 a1=new Assignment_3();
	}
}