package Awt_Package;

import java.awt.*;
import java.awt.event.*;

public class B extends Frame
{
	public static void main(String[] args) {
		B b1=new B();
	}
	B(){
		setVisible(true);	
		setSize(400,300);
		
		setLayout(new FlowLayout());
		Button b1=new Button("Button");
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Dialog d=new Dialog(B.this);
				d.setVisible(true);
				d.setSize(300,400);
			}
		});
		add(b1);
	}
}
