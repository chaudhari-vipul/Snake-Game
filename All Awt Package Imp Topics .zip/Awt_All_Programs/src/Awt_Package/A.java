package Awt_Package;

import java.awt.*;

public class A extends Frame
{
	private MenuBar mb;
	private Menu m1,m2,m3,m4;
	private MenuItem I1,I2,I3,I4;
	public static void main(String[] args) 
	{
		A a=new A();
	}
	public A() {
		setVisible(true);
		setSize(500,600);
		init();
		addComponent();
	}
	public void init() {
		mb=new MenuBar();
		m1=new Menu("Menu 1");
		m2=new Menu("Menu 2");
		m3=new Menu("Menu 3");
		m4=new Menu("Menu 4");
		I1=new MenuItem("item-1");
		I2=new MenuItem("item-2");
		I3=new MenuItem("item-3");
		I4=new MenuItem("item-4");
	}
	public void addComponent() {
		setMenuBar(mb);
		mb.add(m1);
		mb.add(m2);
		m1.add(I1);
		m1.add(I2);
		m2.add(m3);
		m2.add(I4);
		m1.add(m3);
		m3.add(I1);
		m3.add(I2);
		m3.add(m4);
		m4.add(I3);
		m4.add(I4);	
	}
}
