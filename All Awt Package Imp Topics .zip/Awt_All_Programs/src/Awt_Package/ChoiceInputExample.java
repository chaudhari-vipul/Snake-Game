package Awt_Package;

public class ChoiceInputExample {

	public static void main(String[] args) 
	{
		MyFrame mf=new MyFrame();
	}

}
