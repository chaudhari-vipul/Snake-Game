package Awt_Package;

import java.awt.*;
import java.awt.event.*;


public class ActionListenerAll implements ActionListener{

	
	public void actionPerformed(ActionEvent e) 
	{
		MenuItem item=(MenuItem)e.getSource();
		if(item.getLabel().equals("New"))
		{
		System.out.println("New the window");
		}
		else if(item.getLabel().equals("OpenFile"))
		{
		System.out.println("openFile the window");
		}
		else if(item.getLabel().equals("Save"))
		{
		System.out.println("Save the program");
		}
		else if(item.getLabel().equals("SaveAll"))
		{
		System.out.println("SaveAll the program");
		}
		else if(item.getLabel().equals("Close"))
		{
		System.out.println("close the window");
		System.exit(0);
		}
		else if(item.getLabel().equals("CloseAll"))
		{
			System.exit(0);
		}
	}

	

}
