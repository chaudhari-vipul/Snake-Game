package Awt_Package;

import java.awt.*;
import java.awt.event.*;

public class CheckBoxExample extends Frame
{
	Checkbox c1,c2;
	Label msg;
	Button ok;
	CheckboxGroup cg;
	public CheckBoxExample() 
	{
		setSize(400,400);
		setLocation(500,250);
		setVisible(true);
		
		cg=new CheckboxGroup();
		c1=new Checkbox("Java     ",cg,true);
		c2=new Checkbox("Python   ",cg,false);
		ok=new Button("ok");
		msg=new Label("Select Any Course");
		setActionButton();
		c1.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) 
			{
			System.out.println(e.getItem());
			System.out.println(e.getStateChange());
			
			}
		});
		c2.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) 
			{
			System.out.println(e.getItem());
			System.out.println(e.getStateChange());
			
			}
		});
		
		setLayout(new GridLayout(5,1,10,10));
		add(msg);
		add(c1);
		add(c2);
		add(ok);
	}
	public void setActionButton() {
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("ok Button Clicked Me");
				System.out.println(c1.getLabel()+"----------------"+c1.getState());
				System.out.println(c2.getLabel()+"----------------"+c2.getState());
			}
		});
	}
	public static void main(String[] args)
	{
		CheckBoxExample c=new CheckBoxExample();
	}

}
