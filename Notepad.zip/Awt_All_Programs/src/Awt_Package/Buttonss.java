package Awt_Package;

import java.awt.*;
import java.awt.event.*;


public class Buttonss extends Frame implements ActionListener 
{
	private TextField t1,t2,t3;
	private Button Add,Sub,Div,Mul,Reset;

	public Buttonss() 
	{
	setVisible(true);	
	setSize(250,500);
	setLocation(100,200);
	setLayout(new FlowLayout(FlowLayout.CENTER,10,10));
	setBackground(Color.DARK_GRAY);
	
	Initialize();
	AddComponents();
	AddActionListener();
	}
	public void Initialize() 
	{
		t1=new TextField(20);	
		t2=new TextField(20);
		t3=new TextField(20);
		
		Add=new Button("Addition");
		Sub=new Button("Substract");
		Div=new Button("Division");
		Mul=new Button("Multiply");
		Reset=new Button("Reset");
	}
	public void AddComponents() 
	{	
		add(t1);
		add(t2);
		add(t3);
		add(Add);
		add(Sub);
		add(Div);
		add(Mul);
		add(Reset);		
	}
	public void AddActionListener() 
	{
		Add.addActionListener(this);
		Sub.addActionListener(this);
		Div.addActionListener(this);
		Mul.addActionListener(this);
		Reset.addActionListener(this);	
	}
	public void actionPerformed(ActionEvent e) 
	{
		String v1=t1.getText();
		String v2=t2.getText();
		
		Integer n1=Integer.parseInt(v1);
		Integer n2=Integer.parseInt(v2);
		Integer ans=0;
		
		Button b=(Button)e.getSource();
		if(b==Add) 
		{
			ans=n1+n2;
		}
		else if(b==Sub) 
		{
			ans=n1-n2;
		}
		else if(b==Div) 
		{
			ans=n1/n2;
		}
		else if(b==Mul) 
		{
			ans=n1*n2;
		}
		else if(b==Reset) 
		{
			t1.setText("");
			t2.setText("");
		}
		
		t3.setText(ans.toString());
		
	}
	public static void main(String[] args) 
	{
		Buttonss b=new Buttonss();
	}
}