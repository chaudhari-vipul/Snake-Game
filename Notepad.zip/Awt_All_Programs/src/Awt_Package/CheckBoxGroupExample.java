package Awt_Package;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class CheckBoxGroupExample extends Frame 
{
	Checkbox c1,c2;
	Label msg;
	Button ok;
	CheckboxGroup cg;
	
	public static void main(String[] args) 
	{
		CheckBoxGroupExample cb=new CheckBoxGroupExample();
	}
	public void init() {
		cg=new CheckboxGroup();
		c1=new Checkbox("Java",cg,true);
		c2=new Checkbox("python",cg,false);
		
		ok=new Button("OK");
		msg=new Label("Select any Course");
		
		ok.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Clicked Button");
				System.out.println(cg.getSelectedCheckbox());
			}
		});
		
	}
	public CheckBoxGroupExample() 
	{
		setVisible(true);
		setSize(300,300);
		setLocation(290,290);
		init();
		setLayout(new GridLayout(5,1,10,10));
		add(msg);
		add(c1);
		add(c2);
		add(ok);
	}
}