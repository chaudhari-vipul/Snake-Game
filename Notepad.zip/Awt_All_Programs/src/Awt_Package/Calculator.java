package Awt_Package;

import java.awt.*;
import java.awt.event.*;/////////*******Painding******///////

public class Calculator extends Frame implements ActionListener
{
	private Button One,Two,Three,Four,Five,Six,Seven,Eight,Nine,Zero,Add,Sub,Mul,Div;
	public Calculator() 
	{
		setVisible(true);	
		setSize(370,500);
		setLocation(100,200);
		setLayout(new FlowLayout(FlowLayout.CENTER,10,10));
		setBackground(Color.DARK_GRAY);
		
		InitializeComponants();
		addComp();
		addActionListener();
	}
	public void InitializeComponants() {
		One=new Button("1");
		Two=new Button("2");
		Three=new Button("3");
		Four=new Button("4");
		Five=new Button("5");
		Six=new Button("6");
		Seven=new Button("7");
		Eight=new Button("8");
		Nine=new Button("9");
		Zero=new Button("0");
		Add=new Button("add");
		Sub=new Button("sub");
		Mul=new Button("mul");
		Div=new Button("div");
	}
	public void addComp() {
		add(One);
		add(Two);
		add(Three);
		add(Four);
		add(Five);
		add(Six);
		add(Seven);
		add(Eight);
		add(Nine);
		add(Zero);
		add(Add);
		add(Sub);
		add(Mul);
		add(Div);
	}
	public void addActionListener() 
	{
		One.addActionListener(this);
		Two.addActionListener(this);
		Three.addActionListener(this);
		Four.addActionListener(this);
		Five.addActionListener(this);
		Six.addActionListener(this);
		Seven.addActionListener(this);
		Eight.addActionListener(this);
		Nine.addActionListener(this);
		Zero.addActionListener(this);
		Add.addActionListener(this);
		Sub.addActionListener(this);
		Div.addActionListener(this);
		Mul.addActionListener(this);	
	}
	public static void main(String[] args) 
	{
	Calculator cal=new Calculator();
	}


	public void actionPerformed(ActionEvent e) 
	{
			String v1=One.getName();
			
			System.out.println(v1);
					
	}

}
