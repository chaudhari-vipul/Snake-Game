package Awt_Package;

import java.awt.*;
import java.awt.event.*;

public class MyFrame extends Frame
{
	public MyFrame() 
	{
		
		setVisible(true);
		setSize(250,300);
		setLocation(200,300);
		setLayout(new FlowLayout());
		
		List l=new List(3,true);
		l.add("A");
		l.add("B");
		l.add("C");
		l.add("D");
		l.add("E");
		l.add("F");
		l.add("G");
		
		Button b=new Button("Submit");
		
		add(l);
		add(b);
		
		l.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e) {
			System.out.println("List Action");
			}
		});
		b.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
			String[] s=l.getSelectedItems();	
			int [] i=l.getSelectedIndexes();
			System.out.println("--------------");
			for (int j : i) {
				System.out.println(j);	
			}
			for (String  s1: s) {
				System.out.println(s1);	
			}
			System.out.println("--------------");
			}
		});
	}
}
