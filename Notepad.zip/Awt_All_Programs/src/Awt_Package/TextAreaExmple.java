package Awt_Package;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class TextAreaExmple extends Frame {

	public static void main(String[] args) 
	{
		TextAreaExmple t=new TextAreaExmple();
	}
	public TextAreaExmple() {
		setVisible(true);
		setSize(250,300);
		setLocation(200,300);
		setLayout(new FlowLayout());
		TextArea t1=new TextArea("This is a Practice Mode",10,20);
		
		Button b=new Button("Submit");
		add(t1);
		add(b);
		
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//t1.setText("Vipul");
			//	System.out.println(t1.getText());
				t1.setEditable(!t1.isEditable());
			}
		});
	}

}
