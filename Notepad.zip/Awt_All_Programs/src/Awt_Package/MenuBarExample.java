package Awt_Package;

import java.awt.*;
import java.awt.event.*;

public class MenuBarExample extends Frame{
	private MenuBar mb;
	private Menu File,Edit,Source,Refactor,Search,Project,Run,Window;
	private MenuItem New,OpenFile,Save,SaveAll,Close,CloseAll;

	public MenuBarExample() {
		setVisible(true);
		setSize(250,300);
		init();
		addComponent();
		addActions();
	}
	public void init() {
		mb=new MenuBar();
		
		File=new Menu("File");
		Edit=new Menu("Edit");
		Source=new Menu("Source");
		Refactor=new Menu("Refactor");
		Search=new Menu("Search");
		Project=new Menu("Project");
		Run=new Menu("Run");
		Window=new Menu("Window");

		New=new MenuItem("New");
		OpenFile=new MenuItem("OpenFile");
		Save=new MenuItem("Save");
		SaveAll=new MenuItem("SaveAll");
		Close=new MenuItem("Close",new MenuShortcut(KeyEvent.VK_X));
		CloseAll=new MenuItem("CloseAll",new MenuShortcut(KeyEvent.VK_C));
	}
	public void addComponent() {
		setMenuBar(mb);
		mb.add(File);
		mb.add(Edit);
		mb.add(Source);
		mb.add(Refactor);
		mb.add(Search);
		mb.add(Project);
		mb.add(Run);
		mb.add(Window);
		

		File.add(New);
		File.add(OpenFile);
		File.add(Save);
		File.add(SaveAll);
		File.add(Close);
		File.add(CloseAll);
		
	}
	public void addActions() {
		ActionListener al=new ActionListenerAll();
		New.addActionListener(al);
		OpenFile.addActionListener(al);
		Save.addActionListener(al);
		SaveAll.addActionListener(al);
		Close.addActionListener(al);
		CloseAll.addActionListener(al);
	}	
	public static void main(String[] args) {
		MenuBarExample m=new MenuBarExample();
	}

}
