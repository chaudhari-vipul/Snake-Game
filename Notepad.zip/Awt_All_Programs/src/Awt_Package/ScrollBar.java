package Awt_Package;

import java.awt.*;

public class ScrollBar extends Frame 
{
	Panel p1;
	ScrollBar sb;
	
	public static void main(String[] args)
	{
		ScrollBar p=new ScrollBar();
	}
	
		ScrollBar()
		{
		setTitle("Example of SrolleBar");
		setVisible(true);
		setSize(300,250);
		setLayout(new BorderLayout());
		
		p1=new Panel();
		p1.setPreferredSize(new Dimension(250,250));
		sb=new ScrollBar();
		sb.add(p1);
		
		p1.add(new Button("File"));
		p1.add(new Button("Edit"));
		p1.add(new Button("Run"));
		p1.add(new TextField("Enter The Name"));
		p1.add(new TextField("Enter The MiddleName"));
		p1.add(new TextField("Enter The SirName"));
		p1.add(new TextField("Enter The Mobile Number"));
		p1.add(new TextField("Enter The Phone Number"));
		p1.add(new TextField("Enter The Age"));
		p1.add(new TextField("Enter The Address"));
		p1.add(new TextField("Enter The District"));
		p1.add(new TextField("Enter The State"));
		p1.add(new TextField("Enter The Gender"));
		p1.add(new TextField("Enter The Eduction"));
		
		
		p1.setBackground(Color.YELLOW);
		add(sb);	
	}

}
