package Game;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class GamePlay extends JPanel  implements ActionListener,KeyListener {
	private Boolean play=false;
	private int score=0;
	private int totalBigs=21;
	private Timer timer;
	private int delay=8;
	private int ballposx=120;
	private int ballposy=350;
	private int ballxdir=-1;
	private int ballydir=-2;
	private int playerx=350;
	private MapGenerator map;
	
	
	public GamePlay() {
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(true);
		
		timer=new Timer(delay,this);
		timer.start();
		
		map=new MapGenerator(3,7);
	}
	public void paint(Graphics g) {
		//black canvas
		g.setColor(Color.black);
		g.fillRect(1,1,692,592);
		//border
		g.setColor(Color.YELLOW);
		g.fillRect(0,0,692,3);
		g.fillRect(0,3,3,592);
		g.fillRect(682,3,3,592);
		//padel
		g.setColor(Color.GREEN);
		g.fillRect(playerx,550,100,8);
		//bricks
		map.draw((Graphics2D )g);
		
		 //ball
		g.setColor(Color.RED);
		g.fillOval(ballposx,ballposy,20,20);
		//score
		g.setColor(Color.GREEN);
		g.setFont(new Font("Serif",Font.BOLD,20));
		g.drawString("Score :"+score,550,30);
		//gameover
		if(ballposy>=570) {
			play=false;
			ballxdir=0;
			ballydir=0;
			g.setColor(Color.GREEN);
			g.setFont(new Font("serif",Font.BOLD,30));
			g.drawString("Game Over  !!! "+score,200,300);
			g.setFont(new Font("serif",Font.BOLD,25));
			g.drawString("Press Enter to Restart.....",230,330);
		}
		if (totalBigs<=0) {
			play=false;
			ballxdir=0;
			ballydir=0;
			g.setColor(Color.GREEN);
			g.setFont(new Font("serif",Font.BOLD,30));
			g.drawString("You Won"+score,200,300);
			g.setFont(new Font("serif",Font.BOLD,25));
			g.drawString("Press Enter to Restart.....",230,330);
		}
	}
	private void moveleft() {
		play=true;
		playerx-=20;
	}
	private void moveright() {
		play=true;
		playerx+=20;
	}
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_LEFT) {
			if(playerx<=0)
				playerx=0;
			else
				moveleft();
		}
		if(e.getKeyCode()==KeyEvent.VK_RIGHT) {
			if(playerx>=600)
				playerx=600;
			else
				moveright();
		}
		if(e.getKeyCode()==KeyEvent.VK_ENTER) {
			if(!play) {
				score=0;
				totalBigs=21;
				ballposx=120;
				ballposy=350;
				ballxdir=-1;
				ballydir=-2;
				playerx=320;
				map=new MapGenerator(3,7);
			}
		}
		repaint();
	}
	public void actionPerformed(ActionEvent e) {
		if(play) {
			if(ballposx<=0) {
				ballxdir=-ballxdir;
			}
			if(ballposx>=670) {
				ballxdir=-ballxdir;
			}
			if(ballposy<=0) {
				ballydir=-ballydir;
			}
			Rectangle ballrect=new Rectangle(ballposx,ballposy,20,20);
			Rectangle paddelrect=new Rectangle(playerx,550,100,8);
		
			if(ballrect.intersects(paddelrect)) {
				ballydir=-ballydir;
			}
			A:for (int i = 0; i < map.map.length; i++) {
				for (int j = 0; j < map.map[0].length; j++) {
					if(map.map[i][j]>0) {
						int width=map.brickwidth;
						int height=map.brickheight;
						int brickxpos=80+j*width;
						int brickypos=50+i*height;
						Rectangle brickrect=new Rectangle(brickxpos,brickypos,width,height);
						if(ballrect.intersects(brickrect)) {
							map.setBrick(0,i,j);
							totalBigs--;
							score+=5;
							
							if(ballposx+19<=brickxpos || ballposx+1>=brickxpos+width) {
								ballxdir=-ballxdir;
							}
							else {
								ballydir=-ballydir;	
							}
							break A;
						}
					
					
					
					}
				}
			}
			
			
			
			
			ballposx+=ballxdir;
			ballposy+=ballydir;
		}
		repaint();
	}
	
	public void keyReleased(KeyEvent e) {
		
	}
	public void keyTyped(KeyEvent e) {
		
	}

	
}
