package com.Advance;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class JSpinnerExample extends JFrame implements ChangeListener {
	JSpinner j1,j2,j3;
	SpinnerModel model1,model2,model3;
	JLabel label;
	public static void main(String[] args) {
		new JSpinnerExample();
	}
	JSpinnerExample(){
		setSize(400,400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		String month[]= {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		String str=String.valueOf(java.time.Year.now());
		int y=Integer.parseInt(str);
		
		 model1=new SpinnerNumberModel(1,1,31,1);
		 model2=new SpinnerListModel(month);
		 model3=new SpinnerNumberModel(y,y-20,y,1);
		 j1=new JSpinner(model1);
		 j2=new JSpinner(model2);
		 j3=new JSpinner(model3);
		 label=new JLabel();
		
		j1.setBounds(100,20,100,50);
		j2.setBounds(100,100,100,50);
		j3.setBounds(100,200,100,50);
		add(j1);
		add(j2);
		add(j3);
		
		j1.addChangeListener(this);
		j2.addChangeListener(this);
		j3.addChangeListener(this);
		label.setBounds(100,300,150,20);
		validate();
		setDob();
		add(label);
		setVisible(true);
	}
	public void setDob() {
		int date=(Integer)j1.getValue();
		int year=(Integer)j3.getValue();
		String month=(String)j2.getValue();
		
		label.setText("DOB IS :"+date+"-"+month+"-"+year);
	}
	public void stateChanged(ChangeEvent e)
	//reset dob in label
	{
		setDob();
	}
}
