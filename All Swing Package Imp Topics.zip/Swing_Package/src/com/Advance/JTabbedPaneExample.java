package com.Advance;

import java.awt.*;
import javax.swing.*;
public class JTabbedPaneExample {
	public static void main(String[] args) {
		JFrame f=new JFrame("NEW INPUT EXAMPLE");
		f.setSize(400,300);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLayout(null);
		JTabbedPane tp=new JTabbedPane();
		tp.setBounds(50,50,250,200);
		JPanel pan1=new JPanel();
		JPanel pan2=new JPanel();
		JPanel pan3=new JPanel();
		pan1.add(new JLabel("THis is my First page......."));
		pan2.add(new JLabel("THis is my Second page......."));
		pan3.add(new JLabel("THis is my Third page......."));
		tp.add("First",pan1);
		tp.add("Second",pan2);
		tp.add("Third",pan3);
		f.add(tp);
		f.setVisible(true);
	}
}
