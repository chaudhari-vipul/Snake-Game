package com.Advance;
import java.awt.*;
import javax.swing.*;
public class JScollbarExample {

	public static void main(String[] args) {
		JFrame jf=new JFrame("NEW INPUT EXAMPLE");
		jf.setSize(400,300);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setLayout(new FlowLayout());
		JTextArea ta=new JTextArea(10,15);
		JScrollPane scrol=new JScrollPane(ta,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jf.add(scrol);
		jf.setVisible(true);
	}
}
