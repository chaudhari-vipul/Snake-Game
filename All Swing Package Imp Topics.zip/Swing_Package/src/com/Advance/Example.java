package com.Advance;

import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.*;

public class Example extends JFrame {

	public static void main(String[] args) {
		new Example();

	}
	Example(){
	setSize(400,400);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setLocationRelativeTo(null);
	JButton first=new JButton("Left");
	JButton second=new JButton("Right");
	
	JSplitPane split =new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
	split.setTopComponent(first);
	split.setBottomComponent(second);
	split.setDividerSize(10);
	split.setDividerLocation(100);
	split.setOneTouchExpandable(true);
	add(split);
	
	
	
	setVisible(true);
}
}