package com.Advance;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class JPopUpMenuExample extends JFrame implements ActionListener{

	public static void main(String[] args) {
		JPopUpMenuExample j=new JPopUpMenuExample();
		
	}
	JPopupMenu pm;
	JMenuItem m1,m2,m3;
	
	JPopUpMenuExample(){
		setSize(500,500);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setLocationRelativeTo(null);
		setLayout(new FlowLayout());
		
		pm=new JPopupMenu();
		m1=new JMenuItem("Item-1");
		m2=new JMenuItem("Item-2");
		m3=new JMenuItem("Item-3");
		m1.addActionListener(this);
		m2.addActionListener(this);
		m3.addActionListener(this);
		pm.add(m1);
		pm.add(m2);
		pm.add(m3);
		add(pm);
		addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) {
			if(e.getButton()==MouseEvent.BUTTON3) {
				int x=e.getX();
				int y=e.getY();
				pm.show(JPopUpMenuExample.this,x,y);
			}
		}});	
	}
	public void actionPerformed(ActionEvent e) 
	{
	if(e.getSource()==m1)	
	{
		System.out.println("Item-1 is selected");
	}
	else if(e.getSource()==m2)	
	{
		System.out.println("Item-2 is selected");	
	}
	else if(e.getSource()==m3)	
	{
		System.out.println("Item-3 is selected");
	}
		
	}
}
