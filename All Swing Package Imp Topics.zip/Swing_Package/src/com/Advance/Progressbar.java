package com.Advance;
import java.awt.*;
import javax.swing.*;
public class Progressbar extends JFrame {
	public static void main(String[] args) {
		new Progressbar();
	}
	Progressbar(){
		setSize(400,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setLayout(new FlowLayout());
		
		JProgressBar pb=new JProgressBar(0,100);
		add(pb);
		pb.setStringPainted(true);
		//pb.setOrientation(SwingConstants.VERTICAL);
		//to increase the progress
		int i=0;
		while(i<=100) {
			if (i>=0 && i<=50) {
				pb.setString("Prosessing........");
			}
			else  if(i>50 && i<=70)
			{
				pb.setString("Wait for sometime........");
			}
			else  if(i>70 && i<=90)
			{
				pb.setString("about to complete........");
			}
			else  if(i==100)
			{
				pb.setString("Finish");
			}
			pb.setValue(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			i=i+10;
		}
		pack();
		setVisible(true);	
	}
}