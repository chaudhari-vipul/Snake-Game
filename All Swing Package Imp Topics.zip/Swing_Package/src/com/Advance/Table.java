package com.Advance;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.text.JTextComponent;
public class Table {
	public static void main(String[] args) 
	{
		String [][]data= {
				{"101","Sonu","21"},
				{"102","Monu","30"},
				{"103","Golu","25"}
		};
		String [] coloumnName= {"Roll_No","Name","Age"};
		DefaultTableModel model=new DefaultTableModel(data,coloumnName);
		JFrame f=new JFrame("Table EXAMPLE");
		f.setSize(400,300);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLayout(new GridLayout(3,1));
		
		JTable t=new JTable(model);
		
		JPanel pn1=new JPanel();
		f.add(new JScrollPane(t));
		f.add(new JPanel());
		f.add(pn1);
		
		JTextField t1=new JTextField();
		JTextField t2=new JTextField();
		JTextField t3=new JTextField();
		
		JButton b1=new JButton("Add");
		JButton b2=new JButton("Update ");
		JButton b3=new JButton("Delete");
		
		pn1.setLayout(new GridLayout(3,3));
		pn1.add(new JLabel("Roll NO"));
		pn1.add(t1);
		pn1.add(b1);
		
		pn1.add(new JLabel("Name"));
		pn1.add(t2);
		pn1.add(b2);
		
		pn1.add(new JLabel("Age"));
		pn1.add(t3);
		pn1.add(b3);
		f.setVisible(true);
		f.validate();
		t.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			int rowIndex=t.getSelectedRow();
			
			int rollno=(int)model.getValueAt(rowIndex, 0);
			String name=(String)model.getValueAt(rowIndex, 1);
			int age=(int)model.getValueAt(rowIndex, 2);
			
			t1.setText(String.valueOf(rollno));
			t2.setText(name);
			t3.setText(String.valueOf(age));
		}
		});
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if(t1.getText().toString().isEmpty()||t2.getText().toString().isEmpty()||t3.getText().toString().isEmpty())
				{
					JOptionPane.showMessageDialog(null,"Plese Fill All the Feild","Error",JOptionPane.ERROR_MESSAGE);

				}
				else {
				int rollno=Integer.parseInt(t1.getText().toString());
				String name=t2.getText().toString();
				int age=Integer.parseInt(t3.getText().toString());
				Object []newRow= {rollno,name,age};
				model.addRow(newRow);
				t1.setText(null);
				t2.setText(null);
				t3.setText(null);
				}
			}
		});
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(t1.getText().toString().isEmpty()||t2.getText().toString().isEmpty()||t3.getText().toString().isEmpty())
				{
					JOptionPane.showMessageDialog(null,"Plese Fill All the Feild","Error",JOptionPane.ERROR_MESSAGE);

				}
				else {
				int rollno=Integer.parseInt(t1.getText().toString());
				String name=t2.getText().toString();
				int age=Integer.parseInt(t3.getText().toString());
				
				int row=t.getSelectedRow();
				model.setValueAt(rollno,row,0);
				model.setValueAt(name,row,1);
				model.setValueAt(age,row,2);
				t1.setText(null);
				t2.setText(null);
				t3.setText(null);
				}
			}
		});
		b3.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
			if(t.getSelectedRow()==-1) {
				JOptionPane.showMessageDialog(null,"Plese Select the row","Error",JOptionPane.ERROR_MESSAGE);
				
			}
			int status =JOptionPane.showConfirmDialog(null,"Plese do yo want to delete this row","conform",JOptionPane.YES_NO_OPTION);
			if(status==JOptionPane.YES_OPTION) {
			model.removeRow(t.getSelectedRow());
			}
			}
		});
		t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	}
}