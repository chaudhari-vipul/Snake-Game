package com.Advance;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ShowConformDailogExample2 {

	public static void main(String[] args) {
			JFrame jf=new JFrame("NEW INPUT EXAMPLE");
				jf.setVisible(true);
				jf.setSize(400,300);
				jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				jf.setLayout(new FlowLayout());
				JButton btn1=new JButton("PLanne");
				btn1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
					int Selection=JOptionPane.showConfirmDialog(jf,"do want to Exit","Conform",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
						if(Selection==JOptionPane.YES_OPTION) {
							System.exit(0);
						}
						else if(Selection==JOptionPane.NO_OPTION) {
							System.out.println("NO Option is Selected");
						}
						if(Selection==JOptionPane.CANCEL_OPTION) {
							System.out.println("cancel Option is Selected");
						}
					}
				});
				jf.add(btn1);
	}

}
