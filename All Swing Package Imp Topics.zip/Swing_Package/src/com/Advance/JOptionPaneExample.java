package com.Advance;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JOptionPaneExample
{
	public static void main(String[] args) {
		JFrame jf=new JFrame("NEW INPUT EXAMPLE");
			jf.setVisible(true);
			jf.setSize(400,300);
			jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jf.setLayout(new FlowLayout());
			JButton btn1=new JButton("PLanne");
			btn1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(jf,"Hello There This is a Plane massage","Message",JOptionPane.PLAIN_MESSAGE);	
				}
			});
			
			JButton btn2=new JButton("Information");
			btn2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(jf,"Hello There This is a INFORMATION massage","INFORMATION",JOptionPane.INFORMATION_MESSAGE);	
				}
			});
			JButton btn3=new JButton("Quetion");
			btn3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(jf,"Hello There This is a QUESTION massage","QUESTION",JOptionPane.QUESTION_MESSAGE);	
				}
			});
			JButton btn4=new JButton("Error");
			btn4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(jf,"Hello There This is a ERROR massage","ERROR",JOptionPane.ERROR_MESSAGE);		
				}
			});
			JButton btn5=new JButton("Warning");
			btn5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(jf,"Hello There This is a WARNING massage","WARNING",JOptionPane.WARNING_MESSAGE);	
				}
			});
			jf.add(btn1);
			jf.add(btn2);
			jf.add(btn3);
			jf.add(btn4);
			jf.add(btn5);
	}
}