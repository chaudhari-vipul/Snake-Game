package com.Advance;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class JCheckBoxMenuItemExample extends JFrame
{
	JMenuItem newFile=new JMenuItem("New");
	JMenuItem open=new JMenuItem("Open");
	JMenuItem undo=new JMenuItem("Undo");
	JMenuItem redo=new JMenuItem("Redo");
	JCheckBoxMenuItem checkmenuitem=new JCheckBoxMenuItem("WordWrap");
	JTextArea ta=new JTextArea("Vipuirhifoguieysdfcuycfbg cefbgxabcfv vfvsea ceavtucfaitbacrf tvcuaevuacf gvceficrgfitgaer");
	public static void main(String[] args) 
	{
		new JCheckBoxMenuItemExample();
	}
	JCheckBoxMenuItemExample()
	{
		setSize(500,500);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		JMenuBar bar=new JMenuBar();
		add(bar,BorderLayout.PAGE_START);
		validate();
		JMenu file=new JMenu("File");
		JMenu edit=new JMenu("Edit");
		JMenu formate=new JMenu("Formate");
		bar.add(file);
		bar.add(edit);
		bar.add(formate);
		
		file.add(newFile);
		file.add(open);
		
		edit.add(undo);
		edit.add(redo);
		
		checkmenuitem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if(checkmenuitem.isSelected())	
			{
				ta.setLineWrap(true);
				ta.setWrapStyleWord(true);
			}
			else {
				ta.setLineWrap(false);
				ta.setWrapStyleWord(false);
			}
			}
		});
		
		formate.add(checkmenuitem);
		add(ta,BorderLayout.CENTER);	
		setVisible(true);
	}
}
