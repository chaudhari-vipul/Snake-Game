package com.Adavance2;

import java.awt.Color;

import javax.swing.*;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

public class JTxtPane {

	public static void main(String[] args) {
		new JTxtPane();
	}
	JTxtPane(){
		JFrame frame=new JFrame();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400,600);
		frame.setVisible(true);
		JTextPane text=new JTextPane();
		text.setText("Hello -");
		
		SimpleAttributeSet atr=new SimpleAttributeSet();
		StyleConstants.setBold(atr, true);
		Document doc=text.getStyledDocument();
		try {
		doc.insertString(doc.getLength(),"Welcome", atr);
		atr=new SimpleAttributeSet();
		StyleConstants.setItalic(atr, true);
		doc.insertString(doc.getLength()," to", atr);
		
		atr=new SimpleAttributeSet();
		StyleConstants.setUnderline(atr, true);
		doc.insertString(doc.getLength()," java-Project", atr);
		
		atr=new SimpleAttributeSet();
		StyleConstants.setForeground(atr,Color.white);
		StyleConstants.setBackground(atr,Color.RED);
		doc.insertString(doc.getLength()," Lerning", atr);
		
		}
		catch(Exception e) {
			
		}
		//text.setCharacterAttributes(atr, true);
		
		JTextField field=new JTextField();
		frame.getContentPane().add(text);
		frame.revalidate();
	}

}
