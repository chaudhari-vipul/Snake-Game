package com.Adavance2;

import java.awt.Color;

import javax.swing.*;

public class JlayeredPanExm extends JFrame{
	JlayeredPanExm() {
		JLayeredPane pan=this.getLayeredPane();
		JButton bt1=new JButton("Red");
		bt1.setBackground(Color.RED);
		bt1.setBounds(20,20,150,150);
		
		JButton bt2=new JButton("Green");
		bt2.setBackground(Color.GREEN);
		bt2.setBounds(40,40,150,150);
		
		JButton bt3=new JButton("Blue");
		bt3.setBackground(Color.BLUE);
		bt3.setBounds(60,60,150,150);
		
		pan.add(bt1,new Integer(10));
		pan.add(bt2,new Integer(20));
		pan.add(bt3,new Integer(30));	
	}
	public static void main(String[] args) {
	JlayeredPanExm j=new JlayeredPanExm();
	j.setSize(500,500);
	j.setLocationRelativeTo(null);
	j.setDefaultCloseOperation(EXIT_ON_CLOSE);
	j.setVisible(true);

	
	}
}
