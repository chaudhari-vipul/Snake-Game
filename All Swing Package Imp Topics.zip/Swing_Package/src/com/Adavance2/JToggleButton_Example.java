package com.Adavance2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JToggleButton_Example extends JFrame implements ActionListener{
	private Color defaultcolor;
	JToggleButton toggle;
	Container c;
	public static void main(String[] args) {
		new JToggleButton_Example();

	}
	JToggleButton_Example(){
		setSize(400,400);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		c=getContentPane();
		c.setLayout(null);
		defaultcolor=c.getBackground();
		toggle=new JToggleButton("OFF");
		toggle.setBounds(200,200,100,50);
		add(toggle);
		toggle.addActionListener(this);
		
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if(toggle.isSelected()) {
			//ON state
			c.setBackground(Color.YELLOW);
			toggle.setText("ON");
		}else {
			//OFF state
			c.setBackground(defaultcolor);
			toggle.setText("OFF");
		}
	}
}
