package com.Adavance2;

import javax.swing.*;

public class JToolTipExample extends JFrame {

	public static void main(String[] args) {
		new JToolTipExample();

	}
	JToolTipExample(){
		setLayout(null);
		JLabel l=new JLabel("password");
		l.setBounds(50,100,80,30);
		add(l);
		
		JPasswordField pass=new JPasswordField();
		pass.setBounds(140,100,100,30);
		add(pass);
		String str="<html> "
				+"<div bgcolor=Yellow color=Blue>"
				+ "<h2>Enter your password</h2> <br/>"
				+"password should be atleast 0 character long"
				+"</div>"
				+ " </html>";
		pass.setToolTipText(str);
		setSize(400,400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
}