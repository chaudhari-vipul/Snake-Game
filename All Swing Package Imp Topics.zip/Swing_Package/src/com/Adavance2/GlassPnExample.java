package com.Adavance2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.pack1.JcomboBox;

public class GlassPnExample  {
	public static void main(String[] args) {
		JFrame g=new JFrame("GlassPane");
		g.setSize(500,500);
		g.setLocationRelativeTo(null);
		g.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel p1=new JPanel();
		final JLabel lab=new JLabel("Glass Pan Example");
		JButton bt1=new JButton("Click me");
		JButton bt2=new JButton("Show");
		p1.add(lab);
		p1.add(bt1);
		p1.add(bt2);
		g.getContentPane().add(p1);
		g.setVisible(true);
		bt1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lab.setVisible(!lab.isVisible());
			}
		});
		g.setGlassPane(new JComponent() {
		public void paint(Graphics b) {
			b.setColor(new Color(0,0,0,150));
			b.fillRect(0, 0, getWidth(),getHeight() );
		}});
			
		final Container glasspane=(Container)g.getGlassPane();
		glasspane.setLayout(new GridBagLayout());
		JButton hide=new JButton("Hide");
		glasspane.add(hide);
		glasspane.addMouseListener(new MouseAdapter() {});
		bt2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				glasspane.setVisible(true);
			}
		});
		hide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				glasspane.setVisible(false);
			}
		});
		
		
	}
}
