package com.Adavance2;
import java.awt.event.*;
import java.io.*;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
public class fileChooser implements  ActionListener{
	JFileChooser filechooser;
	public fileChooser() {
		JFrame frame=new JFrame("File Chooser");
		frame.setSize(500,500);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel=new JPanel();
		frame.add(panel);
		JButton open=new JButton("Open");
		JButton save=new JButton("Save");
		panel.add(open);
		panel.add(save);
		frame.setVisible(true);
		
		open.addActionListener(this);
		save.addActionListener(this);
		filechooser=new JFileChooser("C:\\Users\\admin\\eclipse-workspace");
		//filechooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		filechooser.setMultiSelectionEnabled(true);
		
		filechooser.setAcceptAllFileFilterUsed(false);
		
		FileNameExtensionFilter filter1=new FileNameExtensionFilter("only Text file(.txt)", "txt");
		FileNameExtensionFilter filter2=new FileNameExtensionFilter("only java file(.java)", "java");
		FileNameExtensionFilter filter3=new FileNameExtensionFilter("only html file(.html)", "html");
		FileNameExtensionFilter filter4=new FileNameExtensionFilter("only image file(.jpg)", "jpg");
		
		filechooser.addChoosableFileFilter(filter1);
		filechooser.addChoosableFileFilter(filter2);
		filechooser.addChoosableFileFilter(filter3);
		filechooser.addChoosableFileFilter(filter4);
		
	
	
	
	}
	
	
	
		public void actionPerformed(ActionEvent e) {
	//	int selectedoption=filechooser.showDialog(null,"Open My File");
		if(e.getActionCommand().equalsIgnoreCase("open"))
		{
		int selectedoption=filechooser.showOpenDialog(null);
			if(selectedoption==JFileChooser.APPROVE_OPTION){
			File [] files=filechooser.getSelectedFiles();
			for (int i = 0; i < files.length; i++) {
				File file=files[i];
				System.out.println("\n selected file is :"+file.getAbsolutePath());
				}}
			else {
				System.out.println("User Cancelled this Dailog");	
				 }
		}
		else 
		{
			int selectedoption=filechooser.showSaveDialog(null);
			if(selectedoption==JFileChooser.APPROVE_OPTION){
		System.out.println("selected file is :"+filechooser.getSelectedFile().getAbsolutePath());
				}
			else {
				System.out.println("User Cancelled this Dailog");	
				 }
		}	
		}
	
	public static void main(String[] args) {
		new fileChooser();
		
	}

}
