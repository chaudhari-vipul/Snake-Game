package com.Adavance2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class AppletDemo extends JApplet implements ActionListener{
	JTextField t1;
	JButton b1;
	public void init() {
		setLayout(null);
		t1=new JTextField();
		b1=new JButton("Press me");
		t1.setBounds(20,20,100,30);
		b1.setBounds(20,40,100,20);
		add(t1);
		add(b1);
		b1.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		t1.setText("Boooommmmmmm");
	}
}
