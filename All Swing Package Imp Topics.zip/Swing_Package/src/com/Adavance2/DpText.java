package com.Adavance2;
import java.awt.*;
import javax.swing.*;
public class DpText extends JFrame {
	JDesktopPane dp;
	public static void main(String[] args) {
		new DpText();
	}
	DpText(){
		dp=new JDesktopPane();
		Display(dp);
		add(dp,BorderLayout.CENTER);
		setSize(400,400);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	public void Display(JDesktopPane dp) {
		int numFrame=3,x=30,y=30;
		for (int i = 0; i < numFrame; i++) 
		{
		JInternalFrame iframe=new JInternalFrame("MyInternal Frame"+(i+1),true,true,true);
		iframe.setBounds(x,y,250,100);
		iframe.setBackground(Color.cyan);
		iframe.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
		iframe.add(new JLabel("I Love Java....."));
		iframe.setVisible(true);
		dp.add(iframe);
		y+=100;
		}	
	}
}