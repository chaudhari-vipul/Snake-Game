package com.Adavance2;

import java.awt.*;

import javax.swing.*;

public class InternalFrameExe extends JFrame 
{
	InternalFrameExe(){
		setLayout(null);
		JInternalFrame iframe=new JInternalFrame("My Internal Frame",true,true,true,true);
		initframe(iframe);
		add(iframe);
		setSize(400,400);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	public static void main(String[] args) {
		new InternalFrameExe();
	}
	public void initframe(JInternalFrame iframe) {
		iframe.setSize(300,200);
		iframe.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
		iframe.setLocation(50,50);
		iframe.setLayout(new FlowLayout());
		iframe.add(new JButton("My Button"));
		
		iframe.setVisible(true);
	}
}
