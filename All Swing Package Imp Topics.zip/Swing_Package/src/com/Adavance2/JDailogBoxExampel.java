package com.Adavance2;
import java.awt.event.*;
import javax.swing.*;
public class JDailogBoxExampel implements ActionListener  {
	JFrame frame;
	JButton btn,b2;
	JPanel pan;
	JDialog d,d2;
	public static void main(String[] args) {
		new JDailogBoxExampel();
	}
	JDailogBoxExampel(){
		frame=new JFrame("JFrame"); 
		frame.setSize(300,250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		pan=new JPanel();
		frame.add(pan);
		btn=new JButton("Click-1");
		btn.addActionListener(this);
		pan.add(btn);
		frame.validate();
		frame.pack();
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("Click-1")) {
			firstDailog();
		}
		else if(e.getActionCommand().equals("Click-2")) {
			SecondDailog();
		}
	}
	private void firstDailog() {
		d=new JDialog(frame,"JDialog-1");
		d.setSize(200,200);
		d.setVisible(true);
		JPanel panel=new JPanel();
		d.add(panel);
		
		b2=new JButton("Click-2");
		panel.add(b2);
		b2.addActionListener(this);
		
	}
	private void SecondDailog() {
		d2=new JDialog(d,"JDialog-2");
		d2.setSize(200,200);
		d2.setVisible(true);
		d2.add(new JLabel("This is Second J-Dialog"));
		
	}
}
