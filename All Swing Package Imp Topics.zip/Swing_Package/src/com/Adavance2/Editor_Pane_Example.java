package com.Adavance2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Editor_Pane_Example extends JFrame{
	JEditorPane jp;
	JButton b;
	public static void main(String[] args) {
		new Editor_Pane_Example();
	}
	Editor_Pane_Example(){
	
		jp=new JEditorPane();
//		jp.setContentType("text/plain");
//		jp.setText("Lorem jnbqwdb bdu ibvc kic uiuivv uidsj bqwbuvb qcbbcq bcbqib  bqcjb jcq bqcjbjbqck bbqwciononwve nonqnbw");

		jp.setContentType("text/html");
		jp.setText("<html>"
				+ "<h1 color=red>Hello World</h1>"
				+ "<p>This is my paragraph</p>"
				+ "<hr>"
				+ "<ol>"
				+ "<li>item-1</li>"
				+ "<li>item-2</li>"
				+ "<li>item-3</li>"
				+ "</ol>"
				+ "</html>");
		add(jp,BorderLayout.CENTER);
		b=new JButton("Show code");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println(""+jp.getText());
				
			}
		});
		add(b,BorderLayout.PAGE_END);
		setSize(400,400);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
}
