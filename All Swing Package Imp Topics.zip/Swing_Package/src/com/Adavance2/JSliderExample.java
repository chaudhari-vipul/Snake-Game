package com.Adavance2;

import java.awt.FlowLayout;

import javax.swing.*;
import javax.swing.event.*;
public class JSliderExample extends JFrame implements ChangeListener
{
	JSlider s1;
	JLabel l;
	
	public static void main(String[] args) {
		new JSliderExample();
	}
	JSliderExample(){
	
	s1=new JSlider();
	add(s1);
	
	s1.setMinimum(0);
	s1.setMaximum(200);
	s1.setPaintTicks(true);
	s1.setPaintLabels(true);
	s1.setMajorTickSpacing(50);
	s1.setMinorTickSpacing(5);
	
	s1.addChangeListener(this);
	//s1.setOrientation(JSlider.VERTICAL);
	
	
	l=new JLabel();
	l.setText("The Value of Slider  :"+s1.getValue());
	add(l);
	
	setSize(300,300);
	setLocationRelativeTo(null);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setLayout(new FlowLayout());
	setVisible(true);
	}
	public void stateChanged(ChangeEvent e) 
	{
		l.setText("The Value of Slider :"+s1.getValue());
	}
}
