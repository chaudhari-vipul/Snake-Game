package com.Adavance2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ToolBarExample extends JFrame implements ActionListener {
	JToolBar bar=new JToolBar();
	JButton bt1=new JButton("Button-1");
	JButton bt2=new JButton("Button-2");
	JTextField textfield=new JTextField();
	JComboBox combo=new JComboBox(new String[] {"item-1","item-2","item-3","item-4"});
	JLabel label=new JLabel();
	
	
	ToolBarExample(){
	setSize(600,400);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setLocationRelativeTo(null);
	bar.add(combo);
	bar.add(textfield);
	bar.add(bt1);
	bar.addSeparator();
	bar.add(bt2);
	bar.setFloatable(false);
	combo.addActionListener(this);
	textfield.addActionListener(this);
	bt1.addActionListener(this);
	bt2.addActionListener(this);
	
	add(BorderLayout.NORTH,bar);
	add(label);
	setVisible(true);
	revalidate();
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1) 
		{
			label.setText("Button-1 Click");
		}
		else if(e.getSource()==bt2)
		{
			label.setText("Button-2 Click");
		}
		else if(e.getSource()==textfield) 
		{
			label.setText("You Enter  :"+textfield.getText());
		}
		else if(e.getSource()==combo) 
		{
			label.setText(combo.getSelectedItem()+" Selected");
		}
		
	}
	public static void main(String[] args) {
		new ToolBarExample();
	}
}
