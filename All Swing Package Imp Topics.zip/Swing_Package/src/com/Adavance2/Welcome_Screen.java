package com.Adavance2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Welcome_Screen extends JFrame 
{
	Timer time;
	public static void main(String[] args) 
	{
		new Welcome_Screen();
	}
	Welcome_Screen()
	{
		DisplayWelcomeScreen();
	setSize(400,400);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setLocationRelativeTo(null);
	JLabel label=new JLabel("Wel-Come To Java Programme");
	label.setHorizontalAlignment(SwingConstants.CENTER);
	add(label);
//	setVisible(true);
	}
	private void DisplayWelcomeScreen() {
	final JWindow w=new JWindow(this);
	w.setSize(400,400);
	w.setLocationRelativeTo(null);
	JPanel pan=new JPanel();
	w.add(pan);
	String imgpath="AdminImage.jpg";
	JLabel label1=new JLabel(new ImageIcon(imgpath));
	pan.add(label1);
	pan.setBackground(Color.WHITE);
	label1.setHorizontalAlignment(SwingConstants.CENTER);
	pan.setBorder(BorderFactory.createLineBorder(Color.BLACK));
	JProgressBar progress=new JProgressBar(0,100);
	progress.setForeground(Color.ORANGE);
	w.add(BorderLayout.PAGE_END,progress);
	w.revalidate();
	time=new Timer(100, new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		int x=progress.getValue();
		if(x==100) {
			w.dispose();
			Welcome_Screen.this.setVisible(true);
			time.stop();
		}else {
			progress.setValue(x+2);
		}
		
		}
	});
	time.start();
	
	
	w.setVisible(true);
	}
}
