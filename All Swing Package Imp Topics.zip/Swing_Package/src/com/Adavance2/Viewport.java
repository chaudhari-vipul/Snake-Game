package com.Adavance2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Viewport {

	public static void main(String[] args) {
		JFrame frame=new JFrame("ViewPort Example");
		frame.setSize(600,600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		
		ImageIcon icon=new ImageIcon("Vip Iconss.png");
		JLabel label=new JLabel(icon);
		JScrollPane pane=new JScrollPane(label);
		pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);

		frame.add(pane);
		
		pane.setViewportBorder(BorderFactory.createLineBorder(Color.RED));
		
		final JViewport viewport=new JViewport();
		JButton bt1=new JButton("Move-Up");
		JButton bt2=new JButton("Move-Down");
		JButton bt3=new JButton("Move-Left");
		JButton bt4=new JButton("Move-Right");
		JPanel panel=new JPanel();
		panel.add(bt1);
		panel.add(bt2);
		panel.add(bt3);
		panel.add(bt4);
		frame.add(panel,BorderLayout.NORTH);
		
		bt1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Point origin=viewport.getViewPosition();
			Point neworigin=new Point(origin.x,origin.y-100);
			viewport.setViewPosition(neworigin);
			}
		});
		bt2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Point origin=viewport.getViewPosition();
			Point neworigin=new Point(origin.x,origin.y+100);
			viewport.setViewPosition(neworigin);
			}
		});
		bt3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Point origin=viewport.getViewPosition();
			Point neworigin=new Point(origin.x-100,origin.y);
			viewport.setViewPosition(neworigin);
			}
		});
		bt4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Point origin=viewport.getViewPosition();
			Point neworigin=new Point(origin.x+100,origin.y);
			viewport.setViewPosition(neworigin);
			}
		});
		frame.setVisible(true);
	}

}
