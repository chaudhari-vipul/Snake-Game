package com.Adavance2;

import java.awt.event.*;

import javax.swing.*;
public class Example implements ActionListener 
{
	JFrame frame1,frame2;
	JButton b1,b2;
	JLabel label1;
	JPanel pan,pan1;
	public static void main(String[] args) 
	{
		new Example();
	}
	Example(){
		frame1=new JFrame("Main Frame");
		frame1.setSize(400,400);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.setLocationRelativeTo(null);
		
		b1=new JButton("Click");
		label1=new JLabel("Massege will appear here");
		
		pan=new JPanel();
		pan.add(b1);
		pan.add(label1);
		frame1.add(pan);
		b1.addActionListener(this);
		
		
		
		frame1.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("Click")) {
			frame1.dispose();
			frame2=new JFrame("Enter Your Message");
			frame2.setSize(400,200);
			frame2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame2.setLocationRelativeTo(frame1);
			frame2.setVisible(true);
			JTextField t1=new JTextField();
			t1.setColumns(20);
			b2=new JButton("Submit");
			pan1=new JPanel();
			pan1.add(t1);
			pan1.add(b2);
			frame2.add(pan1);
			b2.addActionListener(this);
			
		}
		else if(e.getActionCommand().equals("Submit")) {
			String msg=b1.getText().toString();
			label1.setText(msg);
			frame2.dispose();
			frame1.setVisible(true);
		}
	}
	
	
}
