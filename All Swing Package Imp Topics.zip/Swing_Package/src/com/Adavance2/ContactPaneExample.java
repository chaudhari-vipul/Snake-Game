package com.Adavance2;

import java.awt.FlowLayout;

import javax.swing.*;

public class ContactPaneExample extends JFrame {

	ContactPaneExample(){
		JRootPane pan=this.getRootPane();
		JButton btn=new JButton("Press");
		JMenuBar menubar=new JMenuBar();
		JMenu file=new JMenu("File");
		file.add("New");
		file.add("Open");
		file.add("Save");
		file.add("Close");
		menubar.add(file);
		pan.getContentPane().add(btn);
		pan.setJMenuBar(menubar);
	}

	public static void main(String[] args) {
		ContactPaneExample frame=new ContactPaneExample();
		frame.setSize(500,500);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setLayout(new FlowLayout());
		frame.setVisible(true);
		
	}

}
