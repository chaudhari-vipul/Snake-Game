package com.Adavance2;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;
public class JlistExam extends JFrame {
	JTextField textfield=new JTextField(15);
	JButton bt1=new JButton("Add");
	JButton bt2=new JButton("Update");
	JButton bt3=new JButton("Delete");
	int updateIndex=0;
	JlistExam(){
		setSize(400,600);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridLayout(1,2));
		
		JList list=new JList();
		JPanel panel=new JPanel();
		add(panel);
		panel.add(new JScrollPane(list));
		
		DefaultListModel model=new DefaultListModel();
		model.addElement("HighSchool");
		model.addElement("Inter");
		model.addElement("Bachelore");
		model.addElement("Master");
		model.addElement("Professor");
		list.setModel(model);
		
		JPanel pan=new JPanel();
		add(pan);
		pan.add(textfield);
		pan.add(bt1);
		pan.add(bt2);
		pan.add(bt3);
		
		setVisible(true);
		
		bt1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!textfield.getText().toString().isEmpty()) 
				{
				String input=textfield.getText().toString();
				model.addElement(input);
				textfield.setText(null);
				}
			}
		});
		list.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) {
			if(e.getClickCount()==2) {
				updateIndex=list.getSelectedIndex();
				textfield.setText((String)model.get(updateIndex));
			}
		}});
		bt2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!textfield.getText().toString().isEmpty()) 
				{
				String item=textfield.getText().toString();
				model.set(updateIndex,item);
				textfield.setText(null);
				}
			}
		});
		bt3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				model.remove(list.getSelectedIndex());
				
			}
		});
		}
	public static void main(String[] args) {
		new JlistExam();
	}
}
