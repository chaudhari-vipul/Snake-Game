package com.Adavance2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class JColorChoosesExe  {

	public static void main(String[] args) {
		JFrame frame=new JFrame("Color Chooser");
		frame.setSize(400,500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		final Container c=frame.getContentPane();
		c.setLayout(new GridBagLayout());
		JButton btn=new JButton("Change Color");
		c.add(btn);
		btn.addActionListener(new ActionListener() {
			
		public void actionPerformed(ActionEvent e) {
			Color color=JColorChooser.showDialog(null,"Select Color", Color.BLACK);
			c.setBackground(color);
			}
		});
		frame.revalidate();
	}
}
