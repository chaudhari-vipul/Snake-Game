package com.pack1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class JcomboBox extends Frame implements ActionListener
{
	public static void main(String[] args) {
		JFrame j=new JFrame();
		j.setTitle("Radio Button");
		j.setBounds(100,100,700,500);
		Container c=j.getContentPane();
		c.setLayout(null);
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		String [] s= {"A","B","C","D","C","C"};
		
		JComboBox combo=new JComboBox(s);
		combo.setBounds(100,100,100,30);
		c.add(combo);
		combo.setFont(new Font("arial",Font.BOLD,20));
		
		JButton b=new JButton();
		b.setBounds(300,100,100,30);
		c.add(b);
		
		JLabel lab=new JLabel();
		lab.setBounds(100,300,100,30);
		c.add(lab);
		combo.addItem("E");
		combo.removeItem("C");
		
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e)
			{
			String s=(String)combo.getSelectedItem();
			lab.setText(s);
			}
		});
		
		//combo.setSelectedItem("D");//Selected by String 
		//combo.setSelectedIndex(2);// selected on position
		j.setVisible(true);	
}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}















