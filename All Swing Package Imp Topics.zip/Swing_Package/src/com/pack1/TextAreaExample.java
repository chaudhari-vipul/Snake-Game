package com.pack1;
import java.awt.*;
import javax.swing.*;

public class TextAreaExample extends Frame {
	
	public static void main(String[] args) 
	{
		JFrame j=new JFrame();
		j.setBounds(100,100,700,500);
		j.setDefaultLookAndFeelDecorated(false);
		Container c=j.getContentPane();
		c.setLayout(null);
		JTextArea area=new JTextArea();
		area.setBounds(100,100,400,200);
		area.setText("Vipul Easy");
		area.setFont(new Font("Arial",Font.BOLD,15));
		//area.setEditable(false);
		area.setLineWrap(true);//only write in textBox
		c.add(area);
		j.setVisible(true);
	}
}
