package com.pack1;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class KeyListnerExample extends JFrame implements KeyListener  {

	JTextArea ta;
	Container c=getContentPane();
	
	public static void main(String[] args) {
		KeyListnerExample k=new KeyListnerExample();

	}
	
	KeyListnerExample()
	{
		setTitle("Key Event Example");
		setSize(600,500);
		setBounds(100,100,400,400);
		setLocationRelativeTo(null);
		c.setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		ta=new JTextArea();
		ta.setBounds(10,10,370,330);
		c.add(ta);
		ta.addKeyListener(this);
		setVisible(true);	
	}
	@Override
	public void keyTyped(KeyEvent e) {
		ta.setText(ta.getText()+"\n"+"key is Typed--->"+e.getKeyChar());
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		ta.setText(ta.getText()+"\n"+"key is Pressed-->"+e.getKeyChar());
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		ta.setText(ta.getText()+"\n"+"key is Released-->yy"+e.getKeyChar());
		
	}

}
