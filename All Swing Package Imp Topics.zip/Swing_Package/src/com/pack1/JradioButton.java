package com.pack1;

import java.awt.*;
import javax.swing.*;

public class JradioButton extends Frame {

	public static void main(String[] args) {
		JFrame j=new JFrame();
		j.setTitle("Radio Button");
		j.setBounds(100,100,700,500);
		Container c=j.getContentPane();
		c.setLayout(null);
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JRadioButton r1=new JRadioButton("Male");
		r1.setBounds(100,50,100,20);
		c.add(r1);
		
		JRadioButton r2=new JRadioButton("Female");
		r2.setBounds(200,50,100,20);
		c.add(r2);
		
		ButtonGroup Gender=new ButtonGroup();
		Gender.add(r1);
		Gender.add(r2);
		r2.setSelected(true);
		r1.setFont(new Font("Arial",Font.BOLD,15));
		r2.setFont(new Font("Arial",Font.ITALIC,15));
		
		JRadioButton r3=new JRadioButton("General");
		r3.setBounds(100,100,100,20);
		c.add(r3);
		
		JRadioButton r4=new JRadioButton("OBC");
		r4.setBounds(200,100,100,20);
		c.add(r4);
		
		JRadioButton r5=new JRadioButton("SC");
		r5.setBounds(300,100,100,20);
		c.add(r5);
		
		JRadioButton r6=new JRadioButton("ST");
		r6.setBounds(400,100,100,20);
		c.add(r6);
		
		ButtonGroup Cast=new ButtonGroup();
		Cast.add(r3);
		Cast.add(r4);
		Cast.add(r5);
		Cast.add(r6);
		
		r6.setSelected(true);
//		r4.setEnabled(false);
		
		j.setVisible(true);
	}

}
