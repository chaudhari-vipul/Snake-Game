package com.pack1;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class CaretEvents extends JFrame implements CaretListener {
	JTextField t1;
	JTextArea ta;
	
	public static void main(String[] args) {
		
		CaretEvents a=new CaretEvents();
	}
	CaretEvents(){
		setTitle("Mouse-Event Example");
		setSize(600,500);
		setBounds(100,100,700,500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container c=getContentPane();
		c.setLayout(null);
		
		t1=new JTextField();
		t1.setFont(new Font("Arial",Font.BOLD,20));
		t1.setBounds(50,100,100,30);
		c.add(t1);
		t1.addCaretListener(this);
		ta=new JTextArea();
		ta.setBounds(200,50,300,300);
		c.add(ta);
		setVisible(true);
	}
	@Override
	public void caretUpdate(CaretEvent e) {
		ta.setText(ta.getText()+"caretUpdated");
		
	}
}
