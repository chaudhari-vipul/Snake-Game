package com.pack1;

import java.awt.*;
import javax.swing.*;

public class CheckBox extends Frame {

	public static void main(String[] args) {
		JFrame j=new JFrame();
		j.setTitle("Radio Button");
		j.setBounds(100,100,700,500);
		Container c=j.getContentPane();
		c.setLayout(null);
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JCheckBox c1=new JCheckBox("High School");
		JCheckBox c2=new JCheckBox("Diploma");
		JCheckBox c3=new JCheckBox("B.Tech");
		JCheckBox c4=new JCheckBox("M.Tech");
		
		c1.setBounds(100,50,200,20);
		c2.setBounds(100,100,200,20);
		c3.setBounds(100,150,200,20);
		c4.setBounds(100,200,200,20);
		
		c1.setSelected(true);
		c2.setEnabled(false);
		
		Font font=new Font("Arial",Font.ITALIC,20);
		c1.setFont(font);
		c2.setFont(font);
		c3.setFont(font);
		c4.setFont(font);
		c.add(c1);
		c.add(c2);
		c.add(c3);
		c.add(c4);
		j.setVisible(true);
	}

}
