package com.pack1;

import javax.swing.*;

public class menuss extends JFrame
{
	menuss(){
		setSize(600,500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		JMenuBar menubar=new JMenuBar();
		
		JMenu file=new JMenu("file");
		JMenuItem i1=new JMenuItem("new"); 
		JMenuItem i2=new JMenuItem("open"); 
		JMenuItem i3=new JMenuItem("save"); 
		file.add(i1);
		file.add(i2);
		file.add(i3);
		menubar.add(file);
		setJMenuBar(menubar);
		
		JMenu edit=new JMenu("Edit");
		JMenuItem i4=new JMenuItem("Undo");
		JMenuItem i5=new JMenuItem("Redo");
		edit.add(i4);
		edit.add(i5);
		file.add(edit);
		setJMenuBar(menubar);
		
		setVisible(true);
	}
	public static void main(String[] args) {
		menuss m=new menuss();
	}
}
