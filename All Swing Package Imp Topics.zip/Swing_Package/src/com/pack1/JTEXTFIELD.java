package com.pack1;

import java.awt.*;
import javax.swing.*;

public class JTEXTFIELD {

	public static void main(String[] args)
	{
		JFrame J=new JFrame();
		
		J.setVisible(true);
		J.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		J.setBounds(100,100,1000,500);
		Container c=J.getContentPane();
		c.setLayout(null);
		
		JTextField T1=new JTextField();
		T1.setBounds(100,150,120,30);//Left,Top,width,heigth
		c.add(T1);
		T1.setText("Vipul");
		Font f=new Font("Arial",Font.BOLD,25);
		T1.setFont(f);
		T1.setForeground(Color.blue);		
		T1.setBackground(Color.YELLOW);
		//T1.setEditable(false);
	}
}
