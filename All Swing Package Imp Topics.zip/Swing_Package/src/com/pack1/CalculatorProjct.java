package com.pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CalculatorProjct extends JFrame implements ActionListener
{	
	private Container c;
	private JLabel l1,l2;
	private JTextField t1,t2;
	private JButton add,sub,mul,div;
	private JLabel Result;
	CalculatorProjct()
		{
			setTitle("VIPFRAME");
			setSize(500,500);
			setLocation(100,100);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);			
			c=getContentPane();
			c.setLayout(null);
			
			l1=new JLabel("First Number");
			l1.setBounds(10,20,100,20);
			c.add(l1);
	
			t1=new JTextField();
			t1.setBounds(120,20,100,20);
			c.add(t1);
			
			l2=new JLabel("Second Number");
			l2.setBounds(10,50,100,20);
			c.add(l2);
			
			t2=new JTextField();
			t2.setBounds(120,50,100,20);
			c.add(t2);
			
			add=new JButton("+");
			add.setBounds(10,80,50,30);
			c.add(add);
			
			sub=new JButton("-");
			sub.setBounds(70,80,50,30);
			c.add(sub);
			
			mul=new JButton("*");
			mul.setBounds(130,80,50,30);
			c.add(mul);
			
			div=new JButton("/");
			div.setBounds(190,80,50,30);
			c.add(div);
		Result=new JLabel("Result :");
		Result.setBounds(10,120,150,20);
		c.add(Result);
		
		add.addActionListener(this);
		sub.addActionListener(this);
		mul.addActionListener(this);
		div.addActionListener(this);
			setVisible(true);
			}
	public static void main(String[] args)
	{
		CalculatorProjct a=new CalculatorProjct();
	}
	public void actionPerformed(ActionEvent e) 
	{
		try {
	if(e.getSource()==add) {
		int a=Integer.parseInt(t1.getText());
		int b=Integer.parseInt(t2.getText());
		int c=a+b;
		Result.setText("Result :"+c);
	}
	if(e.getSource()==sub) {
		int a=Integer.parseInt(t1.getText());
		int b=Integer.parseInt(t2.getText());
		int c=a-b;
		Result.setText("Result :"+c);
	}
	if(e.getSource()==mul) {
		int a=Integer.parseInt(t1.getText());
		int b=Integer.parseInt(t2.getText());
		int c=a*b;
		Result.setText("Result :"+c);
	}
	if(e.getSource()==div) {
		int a=Integer.parseInt(t1.getText());
		int b=Integer.parseInt(t2.getText());
		int c=a/b;
		Result.setText("Result :"+c);
	}}
		catch (NumberFormatException v) {
			Result.setText("Please Enter Number Only");
		}
		catch (ArithmeticException v2) {
			Result.setText("Can Not Divide Zero");
		}
	
	}
}
