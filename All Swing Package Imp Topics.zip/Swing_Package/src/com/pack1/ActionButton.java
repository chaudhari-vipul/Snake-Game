package com.pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ActionButton extends JFrame implements ActionListener
{
	Container c;
	JButton b;
	ActionButton(){
		c=this.getContentPane();
		c.setLayout(null);
		
		b=new JButton("Clickme");
		b.setBounds(100,100,100,50);
		c.add(b);
		b.addActionListener(this);
	}
	public static void main(String[] args) 
	{	
		ActionButton a=new ActionButton();
		a.setTitle("VIPFRAME");
		a.setSize(500,500);
		a.setLocation(100,100);
		a.setVisible(true);
		a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		c.setBackground(Color.green);	
	}
}
