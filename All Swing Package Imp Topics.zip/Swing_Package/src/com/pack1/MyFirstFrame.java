package com.pack1;
import java.awt.*;
import javax.swing.*;
public class MyFirstFrame {

	public static void main(String[] args) 
	{
		JFrame J=new JFrame();
		J.setVisible(true);
		J.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//close the window
		//J.setSize(700,500);
		//J.setLocation(100,50);
		J.setBounds(100,100,1000,500);
		J.setTitle("My Frame");
		
		ImageIcon icon=new ImageIcon("Vip Iconss.png");
		J.setIconImage(icon.getImage());//set the image icon
		
		Container c=J.getContentPane();
		c.setBackground(Color.YELLOW);
		
		J.setResizable(false);//resiable of your window 
	}
}
