package com.pack1;

import java.awt.*;
import javax.swing.*;

public class LayoutExample extends JFrame 
{
	JButton b1=new JButton("1");
	JButton b2=new JButton("2");
	JButton b3=new JButton("3");
	JButton b4=new JButton("4");
	JButton b5=new JButton("5");
	public static void main(String[] args) 
	{
		LayoutExample l=new LayoutExample();
	}
	LayoutExample()
	{
	setSize(600,500);
	setBounds(100,100,400,400);
	setLocationRelativeTo(null);
	Container c=getContentPane();
	BoxLayout c1=new BoxLayout(c,BoxLayout.Y_AXIS);
	c.setLayout(c1);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	b1.setAlignmentX(Component.CENTER_ALIGNMENT);
	b2.setAlignmentX(Component.CENTER_ALIGNMENT);
	b3.setAlignmentX(Component.CENTER_ALIGNMENT);
	b4.setAlignmentX(Component.CENTER_ALIGNMENT);
	b5.setAlignmentX(Component.CENTER_ALIGNMENT);
	c.add(b1);
	c.add(Box.createRigidArea(new Dimension(0,80))); 
	c.add(b3);
	c.add(b4);
	c.add(b5);
	setVisible(true);
	}
}
