package com.pack1;

import java.awt.*;
import javax.swing.*;

public class Password {

	public static void main(String[] args) {
		JFrame J=new JFrame();
		
		J.setVisible(true);
		J.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		J.setBounds(100,100,1000,500);
		Container c=J.getContentPane();
		c.setLayout(null);
		
		JPasswordField jpass=new JPasswordField();
		jpass.setBounds(100,50,130,50);
		c.add(jpass);
		
		jpass.setText("123");
		jpass.setFont(new Font("arial",Font.BOLD,30));
		
		jpass.setEchoChar('*');
		jpass.setEchoChar((char)0);//how to show pass word in jframe
	}
}
