package com.pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ActionButton3 extends JFrame implements ActionListener
{
	Container c;
	JButton b1=new JButton("Red");
	JButton b2=new JButton("Green");
	JButton b3=new JButton("Yellow");
	ActionButton3(){
		c=this.getContentPane();
		c.setLayout(null);
		
		b1.setBounds(100,100,100,50);
		b2.setBounds(250,100,100,50);
		b3.setBounds(400,100,100,50);

		c.add(b1);
		c.add(b2);
		c.add(b3);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
	}
	public static void main(String[] args) 
	{	
		ActionButton3 a=new ActionButton3();
		a.setTitle("VIPFRAME");
		a.setSize(500,500);
		a.setLocation(100,100);
		a.setVisible(true);
		a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==b1) {
			c.setBackground(Color.RED);
		}
		if(e.getSource()==b2) {
			c.setBackground(Color.GREEN);
		}
		if(e.getSource()==b3) {
			c.setBackground(Color.YELLOW);
		}
		
	}
}
