package com.pack1;

import java.awt.*;
import javax.swing.*;

public class Button {

	public static void main(String[] args)
	{
			JFrame J=new JFrame();
			
			J.setVisible(true);
			J.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			J.setBounds(100,100,1000,500);
			Container c=J.getContentPane();
			c.setLayout(null);
			
			ImageIcon icon=new ImageIcon("Vip Iconss.png");
		
			JButton jb=new JButton(icon);
			jb.setSize(icon.getIconHeight(),icon.getIconWidth());//size of button
			jb.setLocation(100,100);
			jb.setFont(new Font("Arial",Font.BOLD,20));
			jb.setText("myButton");
			jb.setForeground(Color.BLUE);
			jb.setBackground(Color.YELLOW);
			Cursor cur=new Cursor(Cursor.HAND_CURSOR);
			jb.setCursor(cur);
		//	jb.setEnabled(true);
			//jb.setVisible(false);
			c.add(jb);
	}
}
