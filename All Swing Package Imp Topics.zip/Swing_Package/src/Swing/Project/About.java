package Swing.Project;

import java.awt.Font;

import javax.swing.*;

public class About extends JFrame
{
	public About() {
		setBounds(100,100,700,500);
		setTitle("About Notepad Application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon icon=new ImageIcon("Notepadimg.jpg");
		setIconImage(icon.getImage());
		setLayout(null);
		
		JLabel iconlabel=new JLabel(new ImageIcon("Notepadimg.jpg"));
		iconlabel.setBounds(20, 50, 200, 200);
		add(iconlabel);
		JLabel textlable=new JLabel("<html><h1>Welcome to Notepad</h1>Notepad is a text editor, i.e., an app specialized in editing plain text. It can edit text files (bearing the \". txt\" filename extension) and compatible formats, such as batch files, INI files, and log files. Notepad can read and write plain texts encoded in ASCII, UTF-8, and UTF-16 <br>All right reversed@2022</html>");
		textlable.setBounds(200,50,400,300);
		textlable.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,12));
		add(textlable);
	}
	public static void main(String[] args) {
		new About().setVisible(true);
	}
}
