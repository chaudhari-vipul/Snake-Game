package Swing.Graphics;

import java.awt.*;
import javax.swing.*;

public class First extends JFrame {
	public First() {
	setSize(800,800);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setLocationRelativeTo(null);
	//MyPanals panal=new MyPanals();
	MyAnimation anime=new MyAnimation(780,560);
	anime.setBackground(Color.BLACK);
	add(anime);
	}
	public static void main(String[] args) {
		new First().setVisible(true);;
	}
}
