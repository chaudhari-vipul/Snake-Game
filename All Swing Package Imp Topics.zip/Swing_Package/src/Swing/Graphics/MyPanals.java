package Swing.Graphics;

import java.awt.*;
import javax.swing.*;

public class MyPanals extends JPanel {
public void paint(Graphics g) {
	super.paint(g);
	g.setColor(Color.WHITE);
	g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 30));
	g.drawString("Hello Graphics", 50, 50);
	g.drawLine(100, 100, 200, 150);
	//g.drawRect(100,200,100,50);
	g.fillRect(100, 200, 100, 50);
	//g.drawOval(300,200,100,100);
	g.fillOval(300,200,100,100);
	//g.drawArc(400,200,100,100,0,90);
	g.fillArc(400,200,100,100,0,90);
	int x[]= {100,200,300};
	int y[]= {400,300,400};
	int n=3;
	//g.drawPolygon(x, y, n);
	g.fillPolygon(x, y, n);
	int xpoints[]= {100,200,300};
	int ypoints[]= {500,450,500};
	int npoints=3;
	g.drawPolyline(xpoints,ypoints,npoints);
	String url="naturephoto.jpg";
	Image img=new ImageIcon(url).getImage();
	g.drawImage(img, 300,50,200,100, null);	
	//g.clearRect(0,0,700,800);
}
}