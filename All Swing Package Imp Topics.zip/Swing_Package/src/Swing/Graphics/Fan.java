package Swing.Graphics;

import java.awt.*;

import javax.swing.*;

public class Fan extends JPanel{
	int x;
	int y;
	int fanwidth=300;
	int fanheigth=300;
	int centerx;
	int centery;
	int angel=0;
	Fan(int w,int h){
		this.centerx=w/2;
		this.centery=h/2;
		this.x=centerx-fanwidth/2;
		this.y=centery-fanheigth/2;		
	}
	public void paint(Graphics g) {
	super.paint(g);
	g.setColor(Color.WHITE);
	g.fillArc(x, y, fanwidth, fanheigth, angel,30);
	g.fillArc(x, y, fanwidth, fanheigth,angel+120,30);
	g.fillArc(x, y, fanwidth, fanheigth,angel+240,30);
	g.drawRect(centerx-3, centery, 6, 2*fanheigth);
	angel=(angel+30)%360;
	try {
	Thread.sleep(50);
	}
	catch (Exception e) {
	}
	repaint();
	}
	public static void main(String[] args) {
		Fan fan=new Fan(780,750);
		fan.setBackground(Color.BLACK);
		JFrame f=new JFrame();
		f.setSize(800,800);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		f.add(fan);
	}
}