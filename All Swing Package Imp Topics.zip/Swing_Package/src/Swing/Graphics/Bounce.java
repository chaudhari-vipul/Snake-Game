package Swing.Graphics;

import java.awt.*;
import javax.swing.*;

public class Bounce extends JPanel{
	
	int x=0;
	int y=0;
	int ballWidth=50;
	int ballHeight=50;
	int speedx=10;
	int speedy=10;
	int max_x,max_y;
	Bounce(int w,int h){
		this.max_x=w-ballWidth;
		this.max_y=h-ballHeight;
		
				
	}
	public void paint(Graphics g) {
	super.paint(g);
	g.setColor(Color.RED);
	g.fillOval(x,y,ballWidth,ballHeight);
	try {
	Thread.sleep(10);
	}
	catch (Exception e) {
	}
	if(x>max_x ||x<0) {
		speedx=-speedx;
	}
	if(y>max_y ||y<0) {
		speedy=-speedy;
	}
	x+=speedx;
	y+=speedy;
	repaint();
}
	public static void main(String[] args) {
		Bounce bounce=new Bounce(780,750);
		bounce.setBackground(Color.BLACK);
		JFrame f=new JFrame();
		f.setSize(800,800);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		f.add(bounce);
	}
}
