package Swing.Graphics;

import java.awt.*;
import javax.swing.*;

public class MyAnimation extends JPanel {
	int x=0,y=100,w=100,h=50;
	int stepsize=10;
	int max_x,max_y;
	MyAnimation(int w1,int h1){
		this.max_x=w1;
		this.max_y=h1;	
	}
	public void paint(Graphics g) {
	super.paint(g);
	g.setColor(Color.WHITE);
	g.fillRect(x,y,w,h);
	
	if (x+w>max_x || x<0) {
		stepsize=-stepsize;
		x=x+stepsize;
	}
	x=x+stepsize;
	try {
	Thread.sleep(10);
	}
	catch(Exception x) {
		
	}
	repaint();	
}
	public static void main(String[] args) {
		MyAnimation myanemi=new MyAnimation(780,750);
		myanemi.setBackground(Color.BLACK);
		JFrame f=new JFrame();
		f.setSize(800,800);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		f.add(myanemi);
	}
}